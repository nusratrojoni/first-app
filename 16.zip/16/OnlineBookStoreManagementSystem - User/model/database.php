<?php

function dbConnection(){

    $conn = mysqli_connect('localhost', 'root', '', 'user');
    return $conn;
    
}

?>